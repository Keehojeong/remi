<?php

$con=mysqli_connect("211.218.150.109","ci2020remi","2020remi","ci2020remi");

mysqli_set_charset($con,"utf8");

if (mysqli_connect_errno($con))

{
    
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    
}

$userid=$_POST['userid'];
$password=$_POST['password'];
$username=$_POST['username'];
$userbirth=$_POST['userbirth'];
$email=$_POST['email'];
$userphone=$_POST['userphone'];

$result = mysqli_query($con,"INSERT INTO users(userid, password, username, userbirth, email, userphone) VALUES('$userid','$password','$username','$userbirth','$email','$userphone')");



if($result){
    
    echo 'success';
    
}

else{
    
    echo 'failure';
    
}

mysqli_close($con);

?>
