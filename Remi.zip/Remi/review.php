<?php

$con=mysqli_connect("211.218.150.109","ci2020remi","2020remi","ci2020remi");

mysqli_set_charset($con,"utf8");

if (mysqli_connect_errno($con))

{
    
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    
}

$title=$_POST['title'];
$tv=$_POST['tv'];
$review=$_POST['review'];


$result = mysqli_query($con,"INSERT INTO review(title,tv,review) VALUES('$title','$tv','$review')");



if($result){
    
    echo 'success';
    
}

else{
    
    echo 'failure';
    
}

mysqli_close($con);

?>
