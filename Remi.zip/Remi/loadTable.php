<?php
$conn = mysqli_connect("211.218.150.109", "ci2020remi", "2020remi", "ci2020remi", "3306");
mysqli_query($conn, "set names utf8"); // 한글 깨짐 방지

$id = $_POST["id"];
$title = $_POST["title"];
$tv = $_POST["tv"];
$review = $_POST["review"];

$statement = mysqli_prepare($con, "INSERT INTO article VALUES (?,?,?,?)");
mysqli_stmt_bind_param($statement, "sssiis", $id, $title, $tv, $review);
mysqli_stmt_execute($statement);


$response = array();
$response["success"] = true;


echo json_encode($response);
?>